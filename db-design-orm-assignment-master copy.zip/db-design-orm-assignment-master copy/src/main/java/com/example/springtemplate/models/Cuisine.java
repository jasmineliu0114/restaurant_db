package com.example.springtemplate.models;

public enum Cuisine {
    CHINESE, GREEK, INDIAN, ITALIAN, MEXICAN
}
