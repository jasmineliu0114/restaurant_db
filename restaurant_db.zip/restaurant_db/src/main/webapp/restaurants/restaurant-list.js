const {Link, useHistory} = window.ReactRouterDOM;

import restaurantService from "./restaurant-service"
// import RestaurantEditorInline from "./restaurant-editor-inline";

const {useState, useEffect} = React;

const RestaurantList = () => {
  const history = useHistory()
  const [restaurants, setRestaurants] = useState([])
  // const [newRestaurant, setNewRestaurant] = useState({})

  useEffect(() => {
    findAllRestaurants()
  }, [])

  const findAllRestaurants = () =>
        restaurantService.findAllRestaurants()
            .then(restaurants => setRestaurants(restaurants))

  // const updateRestaurant = (id, newRestaurant) =>
  //     restaurantService.updateRestaurant(id, newRestaurant)
  //     .then(restaurant => setRestaurants(restaurants => (restaurants.map(restaurant => restaurant.id === id ? newRestaurant : restaurant))))
  // const deleteRestaurant = (id) =>
  //     restaurantService.deleteRestaurant(id)
  //     .then(restaurants => setRestaurants(restaurants => restaurants.filter(restaurant => restaurant.id !== id)))

  return (
      <div>
        <h2>Restaurant List</h2>
        <button className="btn btn-primary"
                onClick={() => history.push("/restaurants/new")}>
          Add Restaurant
        </button>
        <ul className="list-group">
          {
            restaurants.map(restaurant =>
                <li className = "list-group-item"
                    key={restaurant.id}>
                  <Link to={`/restaurants/${restaurant.id}`}>
                    {restaurant.name}
                  </Link>
                  <Link to={`/restaurants/${restaurant.id}/menuItems`}>
                    {"Menu"}
                  </Link>
                </li>)
          }

        </ul>
      </div>
  )
}

export default RestaurantList;