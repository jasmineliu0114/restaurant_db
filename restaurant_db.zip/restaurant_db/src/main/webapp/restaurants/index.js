import RestaurantList from "../restaurants/restaurant-list";
import MenuItemList from "./menuItem-list";
import RestaurantEditorForm from "../restaurants/restaurant-editor-form";
import MenuItemEditorForm from "./menuItem-editor-form";
import RestaurantMenuItemList from "../menuItems/restaurant-menuItem-list";

const {HashRouter, Link, Route} = window.ReactRouterDOM;

const App = () => {
  console.log(window.ReactRouterDOM)
  return (
      <div className="container-fluid">
        <HashRouter>
          <Route path={["/restaurants", "/"]} exact={true}>
            <RestaurantList/>
          </Route>
          <Route path="/restaurants/:id" exact={true}>
            <RestaurantEditorForm/>
          </Route>
          {/*<Route path={["/menuItems", "/"]} exact={true}>*/}
          {/*  <MenuItemList/>*/}
          {/*</Route>*/}
          <Route path="/menuItems/:id" exact={true}>
            <MenuItemEditorForm/>
          </Route>
        </HashRouter>
      </div>
  );
}

export default App;
