import OrderList from "./order-list";
import OrderEditorForm from "./order-editor-form";

const {HashRouter, Link, Route} = window.ReactRouterDOM;

const App = () => {
  console.log(window.ReactRouterDOM)
  return (
      <div className="container-fluid">
        <HashRouter>
          {/*<Route path={["/restaurants", "/"]} exact={true}>*/}
          {/*    <RestaurantList/>*/}
          {/*</Route>*/}
          {/*<Route path="/restaurants/:id" exact={true}>*/}
          {/*    <RestaurantEditorForm/>*/}
          {/*</Route>*/}
          {/*<Route path="/restaurants/:restaurantId/orders" exact={true}>*/}
          <Route path={["/orders", "/"]} exact={true}>
            <OrderList/>
          </Route>
          <Route path="/orders/:id" exact={true}>
            <OrderEditorForm/>
          </Route>
        </HashRouter>
      </div>
  );
}

export default App;
