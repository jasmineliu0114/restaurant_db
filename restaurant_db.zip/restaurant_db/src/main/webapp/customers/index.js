import CustomerList from "./social/customers/customer-list";
import CustomerFormEditor from "./social/customers/customer-form-editor";
import OrderEditorForm from "../orders/order-editor-form";

const {HashRouter, Route} = window.ReactRouterDOM;
const App = () => {
    return (
        <div className="container-fluid">
            <HashRouter>
                <Route path={["/customers", "/"]} exact={true}>
                    <CustomerList/>
                </Route>
                <Route path="/customers/:id" exact={true}>
                    <CustomerFormEditor/>
                </Route>
                <Route path="/orders/:id" exact={true}>
                    <OrderEditorForm/>
                </Route>
            </HashRouter>
        </div>
    );
}
export default App;