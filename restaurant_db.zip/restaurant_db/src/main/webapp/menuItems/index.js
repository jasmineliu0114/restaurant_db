import MenuItemList from "./menuItem-list";
import MenuItemEditorForm from "./menuItem-editor-form";

const {HashRouter, Link, Route} = window.ReactRouterDOM;
 
const App = () => {
    console.log(window.ReactRouterDOM)
    return (
        <div className="container-fluid">
            <HashRouter>
                <Route path={["/menuItems", "/"]} exact={true}>
                    <MenuItemList/>
                </Route>
                <Route path="/menuItems/:id" exact={true}>
                    <MenuItemEditorForm/>
                </Route>
            </HashRouter>
        </div>
    );
}

export default App;
