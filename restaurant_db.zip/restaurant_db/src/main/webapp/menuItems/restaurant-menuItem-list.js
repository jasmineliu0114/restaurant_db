import menuItemService, {createMenuItemForRestaurant} from "./section-service"
import {findMenuItemsForRestaurant} from "./menuItem-service";

const RESTAURANT_URL = "http://localhost:8080/api/restaurants"
const { useState, useEffect } = React;
const {Link, useParams, useHistory} = window.ReactRouterDOM;

const RestaurantMenuItemList = () => {
  const [menuItems, setMenuItems] = useState([])
  //const [newSection, setNewSection] = useState({})
  const {courseId} = useParams()
  useEffect(() => {
    findMenuItemsForRestaurant(restaurantId)
  }, [])
  const findMenuItemsForRestaurant = (restaurantId) =>
      menuItemService.findMenuItemsForRestaurant(restaurantId)
      .then(menuItems => setMenuItems(menuItems))
  // const createSectionForCourse = (section) =>
  //     sectionService.createSectionForCourse(courseId, section)
  //     .then(section => {
  //       setNewSection({name:''})
  //       setSections(sections => ([...sections, section]))
  //     })
  // const updateSection = (id, newSection) =>
  //     sectionService.updateSection(id, newSection)
  //     .then(section => setSections(sections => (sections.map(section => section.id === id ? newSection : section))))
  // const findSectionsForCourse = (courseId) =>
  //     sectionService.findSectionsForCourse(courseId)
  //     .then(sections => setSections(sections))
  // const deleteSection = (id) =>
  //     sectionService.deleteSection(id)
  //     .then(sections => setSections(sections => sections.filter(section => section.id !== id)))
  return (
      <div>
        <h2>Restaurant Menu Items List</h2>
        <button className="btn btn-primary"
                onClick={() => history.push("/menuItems/new")}>
          Add Menu Item
        </button>
        <ul className="list-group">
          {
            menuItems.map(menuItem =>
                <li className = "list-group-item"
                    key={menuItem.id}>
                  <Link to={`/menuItems/${menuItem.id}`}>
                    {menuItem.name}
                  </Link>
                </li>)
          }
        </ul>
      </div>
  )
}

export default RestaurantMenuItemList;