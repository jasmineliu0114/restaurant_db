// import menuItemService from "./menuItem-service"
//
// const {useState, useEffect} = React;
// const {useParams, useHistory, Link} = window.ReactRouterDOM;
//
// const MenuItemEditor = () => {
//   const {id} = useParams()
//   const [menuItem, setMenuItem] = useState({})
//   const history = useHistory()
//   useEffect(() => {
//     if (id !== "new") {
//       findMenuItemById(id)
//     }
//   }, []);
//   const updateMenuItem = (id, newMenuItem) =>
//       menuItemService.updateMenuItem(id, newMenuItem)
//       .then(() => history.push('/menuItems'))
//   const createMenuItem = (menuItem) =>
//       menuItemService.createMenuItem(menuItem)
//       .then(() => history.push('/menuItems'))
//   const findMenuItemById = (id) =>
//       menuItemService.findMenuItemById(id)
//       .then(menuItem => {
//         menuItem.restaurant = menuItem.restaurant.id
//         setMenuItem(menuItem)
//       })
//
//   const deleteMenuItem = (id) =>
//       menuItemService.deleteMenuItem(id)
//       .then(() => history.push('/menuItems'))
//
//   const createButton = () => {
//     if (id == "new") {
//       return (<div>
//         <button
//             className="btn btn-warning"
//             onClick={() => {
//               history.push('/menuItems')
//             }}>
//           Cancel
//         </button>
//         <button className="btn btn-success"
//                 onClick={() => createMenuItem(
//                     menuItem)}>Create
//         </button>
//       </div>)
//     } else {
//       return (<div>
//         <button
//             className="btn btn-warning"
//             onClick={() => {
//               history.push('/menuItems')
//             }}>
//           Cancel
//         </button>
//         <button
//             className="btn btn-danger"
//             onClick={() => deleteMenuItem(menuItem.id)}>
//           Delete
//         </button>
//
//         <button className="btn btn-primary" onClick={() =>
//             updateMenuItem(menuItem.id, menuItem)}>Save
//         </button>
//       </div>)
//     }
//   }
//   return (
//       <div>
//         <h2>MenuItem Editor</h2>
//
//         <label>Name</label>
//         <input className="form-control"
//                onChange={(e) =>
//                    setMenuItem(menuItem =>
//                        ({...menuItem, name: e.target.value}))}
//                value={menuItem.name}/><br/>
//         <label>Description</label>
//         <input className="form-control"
//                onChange={(e) =>
//                    setMenuItem(menuItem =>
//                        ({...menuItem, description: e.target.value}))}
//                value={menuItem.description}/><br/>
//         <label>Price</label>
//         <input className="form-control"
//                onChange={(e) =>
//                    setMenuItem(menuItem =>
//                        ({...menuItem, price: e.target.value}))}
//                value={menuItem.price}/><br/>
//         <label>Restaurant</label>
//         <input className="form-control"
//                onChange={(e) =>
//                    setMenuItem(menuItem =>
//                        ({...menuItem, restaurant: e.target.value}))}
//                value={menuItem.restaurant}/>
//         <Link to={`/restaurants/${menuItem.restaurant}`}>
//           View Restaurant
//         </Link><br/>
//         <br/>
//         {createButton()}
//       </div>
//   )
// }
//
// export default MenuItemEditor

// import menuItemService, {createMenuItem} from "./menuItem-service"
//
// const {useState, useEffect} = React
// const {useParams, useHistory, Link} = window.ReactRouterDOM;
//
// const MenuItemEditorForm = () => {
//   const {id} = useParams()
//   const [menuItem, setMenuItem] = useState({})
//   const history = useHistory()
//
//   useEffect(() => {
//     if (id !== "new") {
//       findMenuItemById(id)
//     }
//   }, []);
//
//   const findMenuItemById = (id) =>
//       menuItemService.findMenuItemById(id)
//       .then(menuItem => setMenuItem(menuItem))
//   const deleteMenuItem = (id) =>
//       menuItemService.deleteMenuItem(id)
//       .then(() => history.back())
//   const createMenuItem = (menuItem) =>
//       menuItemService.createMenuItem(menuItem)
//       .then(() => history.back())
//   const updateMenuItem = (id, newMenuItem) =>
//       menuItemService.updateMenuItem(id, newMenuItem)
//       .then(() => history.back())
//
//   return (
//       <div>
//         <h2>Menu Item Editor</h2>
//         <label>Id</label>
//         <input
//             className="form-control" value={menuItem.id}/><br/>
//         <label>Name</label>
//         <input
//             className="form-control"
//             onChange={(e) => setMenuItem(
//                 menuItem => ({...menuItem, name: e.target.value}))}
//             value={menuItem.name}/><br/>
//         <label>Description</label>
//         <input
//             className="form-control"
//             onChange={(e) => setMenuItem(menuItem => ({
//               ...menuItem,
//               description: e.target.value
//             }))}
//             value={menuItem.description}/><br/>
//         <label>Price</label>
//         <input
//             className="form-control"
//             onChange={(e) => setMenuItem(
//                 menuItem => ({...menuItem, price: e.target.value}))}
//             value={menuItem.price}/><br/>
//
//         <label>Restaurant</label>
//         <input
//             className="form-control"
//             onChange={(e) =>
//             setMenuItem(menuItem =>
//                 ({...menuItem, restaurant: e.target.value}))}
//                value={menuItem.restaurant}/>
//         <Link to={`/restaurants/${menuItem.restaurant}`}>
//           View Restaurant
//         </Link><br/>
//
//
//         <button className="btn btn-warning"
//                 onClick={() => {
//                   history.back()
//                 }}>
//           Cancel
//         </button>
//         <button className="btn btn-danger"
//                 onClick={() => deleteMenuItem(menuItem.id)}>
//           Delete
//         </button>
//         <button
//             onClick={() => createMenuItem(menuItem)}
//             className="btn btn-success">
//           Create
//         </button>
//         <button className="btn btn-success"
//                 onClick={() => updateMenuItem(menuItem.id, menuItem)}>
//           Save
//         </button>
//       </div>
//   )
// }
//
// export default MenuItemEditorForm

import menuItemService, { findAllOrders } from "./menuItem-service"
const { useState, useEffect } = React;
const { useParams, Link, useHistory } = window.ReactRouterDOM;
const MenuItemFormEditor = () => {
  const { id } = useParams()
  const [menuItem, setMenuItem] = useState({})
  useEffect(() => {
    if (id !== "new") {
      findMenuItemById(id)
    }
  }, []);

  const [orders, setOrders] = useState([])
  useEffect(() => {
    if (id !== "new") {
      findAllOrders(id)
    }
  }, []);

  const findMenuItemById = (id) =>
      menuItemService.findMenuItemById(id)
      .then(menuItem => setMenuItem(menuItem))
  const deleteMenuItem = (id) =>
      menuItemService.deleteMenuItem(id)
      .then(() => history.back())
  const createMenuItem = (menuItem) =>
      menuItemService.createMenuItem(menuItem)
      .then(() => history.back())
  const updateMenuItem = (id, newMenuItem) =>
      menuItemService.updateMenuItem(id, newMenuItem)
      .then(() => history.back())

  const findAllOrders = (id) =>
      menuItemService.findAllOrders(id)
      .then(orders => setOrders(orders))

  return (
      <div>
        <h2>Menu Item Editor</h2>
        <label>Id</label>
        <input
            className="form-control" value={menuItem.id}/><br/>
        <label>Name</label>
        <input
            className="form-control"
            onChange={(e) => setMenuItem(
                menuItem => ({...menuItem, name: e.target.value}))}
            value={menuItem.name}/><br/>
        <label>Description</label>
        <input
            className="form-control"
            onChange={(e) => setMenuItem(menuItem => ({
              ...menuItem,
              description: e.target.value
            }))}
            value={menuItem.description}/><br/>
        <label>Price</label>
        <input
            className="form-control"
            onChange={(e) => setMenuItem(
                menuItem => ({...menuItem, price: e.target.value}))}
            value={menuItem.price}/><br/>
        <label>Restaurant</label>
        <input
            className="form-control"
            onChange={(e) =>
                setMenuItem(menuItem =>
                    ({ ...menuItem, restaurant: e.target.value }))}
            value={menuItem.restaurant} /><br /><br />
        <h2>MenuItem Orders</h2>
        <ul>
          {
            orders.map(order =>
                <li key={order.id}>
                  <Link to={`/orders/${order.id}`}>
                    {order.orderTime}
                  </Link>
                </li>)
          }
        </ul>
        <br></br>
        <button className="btn btn-warning"
                onClick={() => {
                  history.back()
                }}>
          Cancel
        </button>
        <button className="btn btn-danger"
                onClick={() => deleteMenuItem(menuItem.id)}>
          Delete
        </button>
        <button
            onClick={() => createMenuItem(menuItem)}
            className="btn btn-success">
          Create
        </button>
        <button className="btn btn-success"
                onClick={() => updateMenuItem(menuItem.id, menuItem)}>
          Save
        </button>
        <Link to={`/restaurants/${menuItem.restaurant}`}>
          <button>
            View Restaurant
          </button>
        </Link>
      </div>
  )
}

export default MenuItemFormEditor