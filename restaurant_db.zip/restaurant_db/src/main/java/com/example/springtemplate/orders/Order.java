package com.example.springtemplate.orders;

import com.example.springtemplate.customers.Customer;
import com.example.springtemplate.menuItems.MenuItem;
import com.fasterxml.jackson.annotation.JsonIgnore;
import javax.persistence.*;

@Entity
@Table(name = "orders")
public class Order {
  @Id
  @GeneratedValue(strategy =
      GenerationType.IDENTITY)
  private Integer id;
  private String orderTime;
  private String specialInstructions;

  @ManyToOne
  @JsonIgnore
  private Customer customer;

  @ManyToOne
  @JsonIgnore
  private MenuItem menu;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getOrderTime() {
    return orderTime;
  }

  public void setOrderTime(String orderTime) {
    this.orderTime = orderTime;
  }

  public String getSpecialInstructions() {
    return specialInstructions;
  }

  public void setSpecialInstructions(String specialInstructions) {
    this.specialInstructions = specialInstructions;
  }

  public Customer getCustomer() {
    return customer;
  }

  public void setCustomer(Customer customer) {
    this.customer = customer;
  }

  public MenuItem getMenuItem() {
    return menu;
  }

  public void setMenuItem(MenuItem menu) {
    this.menu = menu;
  }
}
