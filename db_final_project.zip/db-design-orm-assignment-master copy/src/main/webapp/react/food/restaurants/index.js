import RestaurantList from "../../../restaurants/restaurant-list";
import RestaurantEditorForm from "../../../restaurants/restaurant-editor-form";

const {HashRouter, Route} = window.ReactRouterDOM;

const App = () => {
  return (
      <div className="container-fluid">
        <HashRouter>
          <Route path={["/restaurants", "/"]} exact={true}>
              <RestaurantList/>
          </Route>
          <Route path="/restaurants/:id" exact={true}>
            <RestaurantEditorForm/>
          </Route>
        </HashRouter>
      </div>
  )
}

export default App;