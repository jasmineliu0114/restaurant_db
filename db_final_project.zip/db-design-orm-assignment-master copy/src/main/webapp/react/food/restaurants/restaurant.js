export const restaurant = {
  table: {
    name: 'restaurants',
    label: 'Restaurant'
  },
  fields: [
    {name: 'id', label: 'Restaurant ID', readonly: true},
    {name: 'name', label: 'Restaurant Name'},
    {name: 'cuisine', label: 'Restaurant Cuisine'},
    {name: 'openTime', label: 'Restaurant Open Time'},
    {name: 'closeTime', label: 'Restaurant Close Time'},
  ]
}