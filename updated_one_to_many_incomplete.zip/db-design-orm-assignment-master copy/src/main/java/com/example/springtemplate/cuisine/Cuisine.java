package com.example.springtemplate.cuisine;

public enum Cuisine {
    CHINESE, GREEK, INDIAN, ITALIAN, MEXICAN
}
