import CustomerList from "./social/customers/customer-list";
import CustomerFormEditor from "./social/customers/customer-form-editor";
// import RestaurantList from "./food/restaurants/restaurant-list";
// import RestaurantEditorForm from "./food/restaurants/restaurant-editor-form";
// import MenuItemList from "./food/menuItems/menuItem-list";
// import MenuItemEditorForm from "./food/menuItems/menuItem-editor-form";

const {HashRouter, Route} = window.ReactRouterDOM;
const App = () => {
    return (
        <div>
            <HashRouter>
                <Route path={["/customers", "/"]} exact={true}>
                    <CustomerList/>
                </Route>
                <Route path="/customers/:id" exact={true}>
                    <CustomerFormEditor/>
                </Route>

                {/*<Route path={["/restaurants", "/"]} exact={true}>*/}
                {/*    <RestaurantList/>*/}
                {/*</Route>*/}
                {/*<Route path="/restaurants/:id" exact={true}>*/}
                {/*    <RestaurantEditorForm/>*/}
                {/*</Route>*/}
                {/*<Route path="/restaurants/:restaurantId/menuItems" exact={true}>*/}
                {/*    <MenuItemList/>*/}
                {/*</Route>*/}

                {/*<Route path={["/menuItems", "/"]} exact={true}>*/}
                {/*    <MenuItemList/>*/}
                {/*</Route>*/}
                {/*<Route path="/menuItems/:id" exact={true}>*/}
                {/*    <MenuItemEditorForm/>*/}
                {/*</Route>*/}
            </HashRouter>
        </div>
    );
}
export default App;