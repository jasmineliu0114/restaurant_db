import restaurantService from "./restaurant-service"
import menuItemService from "../menuItems/menuItem-service"

const {useState, useEffect} = React
const {useParams, useHistory} = window.ReactRouterDOM;

const RestaurantEditorForm = () => {
  const {id} = useParams()
  const [restaurant, setRestaurant] = useState({})
  const [menuItems, setMenuItems] = useState([])

  const history = useHistory()
  useEffect(() => {
    if (id !== "new") {
      findRestaurantById(id)
    }
  }, []);

  const findRestaurantById = (id) =>
      restaurantService.findRestaurantById(id)
      .then(restaurant => setRestaurant(restaurant))
  const deleteRestaurant = (id) =>
      restaurantService.deleteRestaurant(id)
      .then(() => history.back())
  const createRestaurant = (restaurant) =>
      restaurantService.createRestaurant(restaurant)
      .then(() => history.back())
  const updateRestaurant = (id, newRestaurant) =>
      restaurantService.updateRestaurant(id, newRestaurant)
      .then(() => history.back())
  const getMenuItems = (id) =>
      menuItemService.findMenuItemsForRestaurant(id)
      .then(menuItems => setMenuItems(menuItems))

  return (
      <div>
        <h2>
          Restaurant Editor
        </h2>
        <label>Id</label>
        <input
            className="form-control" value={restaurant.id}/>
        <label>Name</label>
        <input
            className="form-control"
            onChange={(e) => setRestaurant(
                restaurant => ({...restaurant, name: e.target.value}))}
            value={restaurant.name}/>
        <label>Cuisine</label>
        <input
            className="form-control"
            onChange={(e) => setRestaurant(restaurant => ({...restaurant, cuisine: e.target.value}))}
            value={restaurant.cuisine}/>
        <label>Open Time</label>
        <input
            className="form-control"
            onChange={(e) => setRestaurant(restaurant => ({...restaurant, openTime: e.target.value}))}
            value={restaurant.openTime}/>
        <label>Close Time</label>
        <input
            className="form-control"
            onChange={(e) => setRestaurant(restaurant => ({...restaurant, closeTime: e.target.value}))}
            value={restaurant.closeTime}/>
        <br/>

        <button className="btn btn-warning"
                onClick={() => {
                  history.back()
                }}>
          Cancel
        </button>
        <button className="btn btn-danger"
                onClick={() => deleteRestaurant(restaurant.id)}>
          Delete
        </button>
        <button className="btn btn-success"
                onClick={() => createRestaurant(restaurant)}>
          Create
        </button>
        <button className="btn btn-success"
                onClick={() => updateRestaurant(restaurant.id, restaurant)}>
          Save
        </button>
        <button className="btn btn-success"
                onClick={() => getMenuItems(restaurant.id)}>
           {/*onClick={() => history.push(`/restaurants/${restaurant.id}/menuItems`)}>*/}
          Menu Items
        </button>
      </div>
  )
}

export default RestaurantEditorForm